"use client";

export default function Timeline() {
  // Vrácení prázdného fragmentu místo null, což je validní JSX element
  return <></>;
}
